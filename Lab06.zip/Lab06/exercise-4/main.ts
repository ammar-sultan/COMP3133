// main.ts
import { Customer } from "./customer";

let customer = new Customer("John", "Smith", 30);
customer.greeter();
customer.GetAge();
