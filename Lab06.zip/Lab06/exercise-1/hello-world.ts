let greeter = (firstName: string, lastName: string) => {
  console.log(`Hello ${firstName} ${lastName}`);
};

greeter("John", "Smith");
